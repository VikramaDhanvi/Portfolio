import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.jsx";
import "bootstrap/dist/css/bootstrap.min.css";           // bootstrap styles
import "bootstrap/dist/js/bootstrap.bundle.min.js";      // bootstrap JS (tooltips etc.)
import "./index.css";                                   // optional custom styles

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// -----------------------------------------------------------------------------
// File: src/App.jsx
// -----------------------------------------------------------------------------
import React from "react";
import Navbar from "./components/Navbar.jsx";
import Hero from "./components/Hero.jsx";
import Summary from "./components/Summary.jsx";
import Experience from "./components/Experience.jsx";
import Projects from "./components/Projects.jsx";
import Education from "./components/Education.jsx";
import Publications from "./components/Publications.jsx";
import Certifications from "./components/Certifications.jsx";
import Skills from "./components/Skills.jsx";
import Contact from "./components/Contact.jsx";

const App = () => (
  <>
    <Navbar />
    <main>
      <Hero />
      <Summary />
      <Experience />
      <Projects />
      <Education />
      <Publications />
      <Certifications />
      <Skills />
      <Contact />
    </main>
  </>
);

export default App;