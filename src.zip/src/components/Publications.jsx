import React from "react";

const Publications = () => (
  <section id="publications" className="py-5 bg-white text-dark">
    <div className="container">
      <h2 className="fw-bold mb-4">Publications</h2>
      <p className="mb-0">
        <strong>Face Liveness Detection Using Image Processing</strong> – Applied computer vision techniques such as head tilting, blinking, and facial landmark detection to differentiate real users from spoof attacks in biometric systems.
      </p>
    </div>
  </section>
);

export default Publications;