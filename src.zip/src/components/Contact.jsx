import React from "react";
import { FaMobile, FaEnvelope } from "react-icons/fa";

const Contact = () => (
  <section id="contact" className="py-5 bg-dark text-white">
    <div className="container text-center">
      <h2 className="fw-bold mb-4 text-white">Get In Touch</h2>
      <p className="mb-3">Have a project or want to collaborate? Let's connect!</p>
      <p className="mb-2"><FaEnvelope className="me-2" /> <a className="text-white fw-semibold" href="mailto:vikramadhanvi_paduchuri@srmap.edu.in">vikramadhanvi_paduchuri@srmap.edu.in</a></p>
      <p><FaMobile className="me-2" /> +91 6281 747 430</p>
    </div>
  </section>
);

export default Contact;