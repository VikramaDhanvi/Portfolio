import React from "react";

const education = [
  {
    institute: "SRM University, Amaravati",
    period: "2022 – 2026",
    degree: "B.Tech in Computer Science",
    gpa: "7.71 / 10.0",
  },
  {
    institute: "AP Board of Intermediate Education (Class 12)",
    period: "2022",
    degree: "Percentage: 72.2%",
  },
  {
    institute: "BSEAP (Class 10)",
    period: "2020",
    degree: "Percentage: 96%",
  },
];

const Education = () => (
  <section id="education" className="py-5 bg-light text-dark">
    <div className="container">
      <h2 className="fw-bold mb-4">Education</h2>
      {education.map((edu) => (
        <div className="mb-4" key={edu.institute}>
          <h5 className="fw-semibold mb-1">{edu.institute}</h5>
          <small className="text-muted d-block">{edu.period}</small>
          <p className="mb-0">
            {edu.degree}
            {edu.gpa ? ` — GPA: ${edu.gpa}` : ""}
          </p>
        </div>
      ))}
    </div>
  </section>
);

export default Education;
