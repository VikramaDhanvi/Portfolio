import React from "react";

const experience = [
  {
    company: "Kodeblue Technologies",
    role: "ML Intern",
    period: "Present",
    description: "Building a hospital recommendation system using machine learning and healthcare data.",
  },
  {
    company: "EDUNET Foundation",
    role: "Frontend Intern",
    period: "2 months",
    description: "Built a student portfolio using HTML, CSS, JavaScript. Gained experience in responsive UI development.",
  },
];

const Experience = () => (
  <section id="experience" className="py-5 bg-light text-dark">
    <div className="container">
      <h2 className="fw-bold mb-4">Work Experience</h2>
      {experience.map((exp) => (
        <div className="mb-4" key={exp.company}>
          <h5 className="mb-1 fw-semibold">{exp.company} <span className="text-muted">— {exp.role}</span></h5>
          <small className="text-muted d-block mb-1">{exp.period}</small>
          <p className="mb-0">{exp.description}</p>
        </div>
      ))}
    </div>
  </section>
);

export default Experience;