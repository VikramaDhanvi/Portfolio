import React from "react";
import { FaGithub, FaLinkedin, FaEnvelope } from "react-icons/fa";

const Navbar = () => (
  <nav className="navbar navbar-expand-lg navbar-dark bg-dark fixed-top shadow-sm">
    <div className="container">
      <a className="navbar-brand fw-bold" href="#hero">Paduchuri Vikrama Dhanvi</a>
      <button
        className="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarNav"
        aria-controls="navbarNav"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span className="navbar-toggler-icon"></span>
      </button>
      <div className="collapse navbar-collapse" id="navbarNav">
        <ul className="navbar-nav ms-auto text-center">
          {[
            ["Summary", "summary"],
            ["Experience", "experience"],
            ["Projects", "projects"],
            ["Education", "education"],
            ["Publications", "publications"],
            ["Certifications", "certifications"],
            ["Skills", "skills"],
            ["Contact", "contact"],
          ].map(([label, id]) => (
            <li className="nav-item" key={id}>
              <a className="nav-link" href={`#${id}`}>{label}</a>
            </li>
          ))}
        </ul>
        <ul className="navbar-nav ms-lg-3 flex-row gap-3">
          <li className="nav-item">
            <a
              className="nav-link"
              href="https://github.com/VikramaDhanvi"
              target="_blank"
              rel="noopener noreferrer"
            >
              <FaGithub size="1.2rem" />
            </a>
          </li>
          <li className="nav-item">
            <a
              className="nav-link"
              href="https://linkedin.com/in/vikrama-dhanvi-paduchuri-291077356/"
              target="_blank"
              rel="noopener noreferrer"
            >
              <FaLinkedin size="1.2rem" />
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link" href="mailto:vikramadhanvi_paduchuri@srmap.edu.in">
              <FaEnvelope size="1.2rem" />
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
);

export default Navbar;