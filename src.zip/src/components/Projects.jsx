import React from "react";
import { FaGithub } from "react-icons/fa";

const projects = [
  {
    name: "Fight Detection System",
    url: "https://github.com/VikramaDhanvi/Fight-Detection",
    desc: "Real‑time video‑based violence detection using CNN models and frame classification.",
  },
  {
    name: "Real Estate Website",
    url: "https://github.com/VikramaDhanvi/Real-Estatw-Website/tree/main",
    desc: "Property listing platform with filtering, chat, and login using PHP, JS, MySQL.",
  },
  {
    name: "Insurance Cost Prediction",
    url: "https://github.com/VikramaDhanvi/Medical-Insurance-Cost-Prediction",
    desc: "Predictive model for estimating medical costs using scikit‑learn regression.",
  },
  {
    name: "Telemedicine Platform",
    url: "https://github.com/VikramaDhanvi/telemedicine-platform",
    desc: "Platform for online doctor consultations with auth, dashboard, and appointment modules.",
  },
];

const Projects = () => (
  <section id="projects" className="py-5 bg-white text-dark">
    <div className="container">
      <h2 className="fw-bold mb-4">Projects</h2>
      <div className="row g-4">
        {projects.map((proj) => (
          <div className="col-md-6" key={proj.name}>
            <div className="card h-100 shadow-sm">
              <div className="card-body d-flex flex-column">
                <h5 className="card-title fw-semibold">{proj.name}</h5>
                <p className="card-text flex-grow-1">{proj.desc}</p>
                <a
                  href={proj.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-outline-primary align-self-start mt-2"
                >
                  <FaGithub className="me-2" />View Code
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  </section>
);

export default Projects;