import React from "react";
import heroImg from "../assets/hero.jpg"; // add a hero image inside assets folder

const Hero = () => (
  <header id="hero" className="vh-100 d-flex align-items-center bg-light text-dark pt-5">
    <div className="container text-center">
      <img
        src={heroImg}
        alt="profile"
        className="rounded-circle mb-3 shadow-sm"
        style={{ width: "160px", height: "160px", objectFit: "cover" }}
      />
      <h1 className="display-5 fw-bold">Paduchuri Vikrama Dhanvi</h1>
      <p className="lead mx-auto" style={{ maxWidth: "600px" }}>
        Computer Science undergraduate skilled in full‑stack development and machine learning.
        Passionate about solving real‑world problems with React, Node.js, Python, and SQL.
      </p>
      <a href="#contact" className="btn btn-primary btn-lg mt-3">Let's Talk</a>
    </div>
  </header>
);

export default Hero;