import React from "react";

const skills = {
  Languages: ["C", "C++", "Python", "JavaScript", "SQL"],
  Frontend: ["HTML", "CSS", "JavaScript", "React.js"],
  Backend: ["Node.js", "Express.js", "PHP"],
  Tools: ["Git", "GitHub", "VS Code", "Postman"],
  Databases: ["MySQL", "MongoDB"],
  Concepts: ["DSA", "OOP", "REST APIs", "Full‑stack Integration"],
};

const Skills = () => (
  <section id="skills" className="py-5 bg-white text-dark">
    <div className="container">
      <h2 className="fw-bold mb-4">Skills</h2>
      <div className="row">
        {Object.entries(skills).map(([category, list]) => (
          <div className="col-md-4 mb-4" key={category}>
            <h6 className="fw-semibold">{category}</h6>
            <ul className="list-unstyled mb-0">
              {list.map((skill) => (
                <li key={skill}>• {skill}</li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  </section>
);

export default Skills;
