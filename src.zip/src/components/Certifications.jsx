import React from "react";

const certs = [
  "AWS Cloud Technical Essentials",
  "Migrating to the AWS Cloud",
  "AWS Fundamentals",
  "Architecting Solutions on AWS",
  "The Joy of Computing Using Python (NPTEL Silver)",
];

const Certifications = () => (
  <section id="certifications" className="py-5 bg-light text-dark">
    <div className="container">
      <h2 className="fw-bold mb-4">Certifications</h2>
      <ul className="list-group list-group-flush">
        {certs.map((c) => (
          <li className="list-group-item bg-light" key={c}>{c}</li>
        ))}
      </ul>
    </div>
  </section>
);

export default Certifications;